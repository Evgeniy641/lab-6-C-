﻿using System;

namespace FractionProject
{
    /// <summary>
    /// Класс для работы с дробями.
    /// </summary>
    public partial class Fraction
    {
        /// <summary>
        /// Числитель дроби.
        /// </summary>
        public int Numerator { get; private set; }

        /// <summary>
        /// Знаменатель дроби.
        /// </summary>
        public int Denominator { get; private set; }

        /// <summary>
        /// Создает новую дробь.
        /// </summary>
        /// <param name="numerator">Числитель.</param>
        /// <param name="denominator">Знаменатель.</param>
        /// <exception cref="ArgumentException">Выбрасывается при нулевом знаменателе.</exception>
        public Fraction(int numerator, int denominator)
        {
            if (denominator == 0)
            {
                throw new ArgumentException("Знаменатель не может быть равен нулю");
            }

            Numerator = numerator;
            Denominator = denominator;
            Simplify();
        }

        /// <summary>
        /// Упрощает дробь.
        /// </summary>
        private void Simplify()
        {
            int gcd = GCD(Math.Abs(Numerator), Math.Abs(Denominator));
            Numerator /= gcd;
            Denominator /= gcd;

            if (Denominator < 0)
            {
                Numerator = -Numerator;
                Denominator = -Denominator;
            }
        }

        /// <summary>
        /// Находит наибольший общий делитель.
        /// </summary>
        /// <param name="a">Первое число.</param>
        /// <param name="b">Второе число.</param>
        /// <returns>Наибольший общий делитель.</returns>
        private static int GCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }

            return a;
        }

        /// <summary>
        /// Возвращает строковое представление дроби.
        /// </summary>
        /// <returns>Строка в формате "числитель/знаменатель".</returns>
        public override string ToString()
        {
            return $"{Numerator}/{Denominator}";
        }

        /// <summary>
        /// Сложение двух дробей.
        /// </summary>
        /// <param name="a">Первая дробь.</param>
        /// <param name="b">Вторая дробь.</param>
        /// <returns>Результат сложения.</returns>
        public static Fraction operator +(Fraction a, Fraction b)
        {
            int newNumerator = (a.Numerator * b.Denominator) + (b.Numerator * a.Denominator);
            int newDenominator = a.Denominator * b.Denominator;
            return new Fraction(newNumerator, newDenominator);
        }

        /// <summary>
        /// Сложение дроби и целого числа.
        /// </summary>
        /// <param name="a">Дробь.</param>
        /// <param name="b">Целое число.</param>
        /// <returns>Результат сложения.</returns>
        public static Fraction operator +(Fraction a, int b)
        {
            return a + new Fraction(b, 1);
        }

        /// <summary>
        /// Сложение целого числа и дроби.
        /// </summary>
        /// <param name="a">Целое число.</param>
        /// <param name="b">Дробь.</param>
        /// <returns>Результат сложения.</returns>
        public static Fraction operator +(int a, Fraction b)
        {
            return new Fraction(a, 1) + b;
        }

        /// <summary>
        /// Вычитание дробей.
        /// </summary>
        /// <param name="a">Уменьшаемая дробь.</param>
        /// <param name="b">Вычитаемая дробь.</param>
        /// <returns>Результат вычитания.</returns>
        public static Fraction operator -(Fraction a, Fraction b)
        {
            int newNumerator = (a.Numerator * b.Denominator) - (b.Numerator * a.Denominator);
            int newDenominator = a.Denominator * b.Denominator;
            return new Fraction(newNumerator, newDenominator);
        }

        /// <summary>
        /// Вычитание целого числа из дроби.
        /// </summary>
        /// <param name="a">Дробь.</param>
        /// <param name="b">Целое число.</param>
        /// <returns>Результат вычитания.</returns>
        public static Fraction operator -(Fraction a, int b)
        {
            return a - new Fraction(b, 1);
        }

        /// <summary>
        /// Вычитание дроби из целого числа.
        /// </summary>
        /// <param name="a">Целое число.</param>
        /// <param name="b">Дробь.</param>
        /// <returns>Результат вычитания.</returns>
        public static Fraction operator -(int a, Fraction b)
        {
            return new Fraction(a, 1) - b;
        }

        /// <summary>
        /// Умножение дробей.
        /// </summary>
        /// <param name="a">Первая дробь.</param>
        /// <param name="b">Вторая дробь.</param>
        /// <returns>Результат умножения.</returns>
        public static Fraction operator *(Fraction a, Fraction b)
        {
            int newNumerator = a.Numerator * b.Numerator;
            int newDenominator = a.Denominator * b.Denominator;
            return new Fraction(newNumerator, newDenominator);
        }

        /// <summary>
        /// Умножение дроби на целое число.
        /// </summary>
        /// <param name="a">Дробь.</param>
        /// <param name="b">Целое число.</param>
        /// <returns>Результат умножения.</returns>
        public static Fraction operator *(Fraction a, int b)
        {
            return a * new Fraction(b, 1);
        }

        /// <summary>
        /// Умножение целого числа на дробь.
        /// </summary>
        /// <param name="a">Целое число.</param>
        /// <param name="b">Дробь.</param>
        /// <returns>Результат умножения.</returns>
        public static Fraction operator *(int a, Fraction b)
        {
            return new Fraction(a, 1) * b;
        }

        /// <summary>
        /// Деление дробей.
        /// </summary>
        /// <param name="a">Делимая дробь.</param>
        /// <param name="b">Делитель дробь.</param>
        /// <returns>Результат деления.</returns>
        /// <exception cref="DivideByZeroException">Выбрасывается при делении на нулевую дробь.</exception>
        public static Fraction operator /(Fraction a, Fraction b)
        {
            if (b.Numerator == 0)
            {
                throw new DivideByZeroException("Деление на нулевую дробь");
            }

            int newNumerator = a.Numerator * b.Denominator;
            int newDenominator = a.Denominator * b.Numerator;
            return new Fraction(newNumerator, newDenominator);
        }

        /// <summary>
        /// Деление дроби на целое число.
        /// </summary>
        /// <param name="a">Дробь.</param>
        /// <param name="b">Целое число.</param>
        /// <returns>Результат деления.</returns>
        public static Fraction operator /(Fraction a, int b)
        {
            return a / new Fraction(b, 1);
        }

        /// <summary>
        /// Деление целого числа на дробь.
        /// </summary>
        /// <param name="a">Целое число.</param>
        /// <param name="b">Дробь.</param>
        /// <returns>Результат деления.</returns>
        public static Fraction operator /(int a, Fraction b)
        {
            return new Fraction(a, 1) / b;
        }

        /// <summary>
        /// Сложение дробей (метод).
        /// </summary>
        /// <param name="other">Другая дробь.</param>
        /// <returns>Результат сложения.</returns>
        public Fraction Sum(Fraction other)
        {
            return this + other;
        }

        /// <summary>
        /// Сложение дроби и целого числа (метод).
        /// </summary>
        /// <param name="number">Целое число.</param>
        /// <returns>Результат сложения.</returns>
        public Fraction Sum(int number)
        {
            return this + number;
        }

        /// <summary>
        /// Вычитание дробей (метод).
        /// </summary>
        /// <param name="other">Вычитаемая дробь.</param>
        /// <returns>Результат вычитания.</returns>
        public Fraction Minus(Fraction other)
        {
            return this - other;
        }

        /// <summary>
        /// Вычитание целого числа из дроби (метод).
        /// </summary>
        /// <param name="number">Целое число.</param>
        /// <returns>Результат вычитания.</returns>
        public Fraction Minus(int number)
        {
            return this - number;
        }

        /// <summary>
        /// Деление дробей (метод).
        /// </summary>
        /// <param name="other">Делитель дробь.</param>
        /// <returns>Результат деления.</returns>
        public Fraction Div(Fraction other)
        {
            return this / other;
        }

        /// <summary>
        /// Деление дроби на целое число (метод).
        /// </summary>
        /// <param name="number">Целое число.</param>
        /// <returns>Результат деления.</returns>
        public Fraction Div(int number)
        {
            return this / number;
        }
    }
}