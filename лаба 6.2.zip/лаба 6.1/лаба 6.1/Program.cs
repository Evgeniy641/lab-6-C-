﻿using System;

namespace FractionProject
{
    /// <summary>
    /// Демонстрационная программа.
    /// </summary>
    class Program
    {
        /// <summary>
        /// Точка входа в программу.
        /// </summary>
        /// <param name="args">Аргументы командной строки.</param>
        static void Main(string[] args)
        {
            Console.WriteLine("=== Демонстрация работы с дробями ===\n");

            DemonstrateBasicOperations();
            DemonstrateComparison();
            DemonstrateCloning();
            DemonstrateCaching();

            Console.WriteLine("\n=== Демонстрация завершена ===");
        }

        /// <summary>
        /// Демонстрация базовых операций.
        /// </summary>
        private static void DemonstrateBasicOperations()
        {
            Console.WriteLine("1. БАЗОВЫЕ ОПЕРАЦИИ:");

            Fraction f1 = new Fraction(1, 3);
            Fraction f2 = new Fraction(2, 3);

            Console.WriteLine($"   f1 = {f1}, f2 = {f2}");
            Console.WriteLine($"   {f1} + {f2} = {f1 + f2}");
            Console.WriteLine($"   {f1} - {f2} = {f1 - f2}");
            Console.WriteLine($"   {f1} * {f2} = {f1 * f2}");
            Console.WriteLine($"   {f1} / {f2} = {f1 / f2}");

            Fraction f3 = new Fraction(3, 4);
            Fraction result = f1.Sum(f2).Div(f3).Minus(5);
            Console.WriteLine($"\n   f1.Sum(f2).Div(f3).Minus(5) = {result}");
        }

        /// <summary>
        /// Демонстрация сравнения дробей.
        /// </summary>
        private static void DemonstrateComparison()
        {
            Console.WriteLine("\n2. СРАВНЕНИЕ:");

            Fraction f4 = new Fraction(1, 2);
            Fraction f5 = new Fraction(2, 4);

            Console.WriteLine($"   {f4} == {f5}: {f4 == f5}");
            Console.WriteLine($"   {f4}.Equals({f5}): {f4.Equals(f5)}");
        }

        /// <summary>
        /// Демонстрация клонирования.
        /// </summary>
        private static void DemonstrateCloning()
        {
            Console.WriteLine("\n3. КЛОНИРОВАНИЕ:");

            Fraction original = new Fraction(3, 5);
            Fraction clone = (Fraction)original.Clone();

            Console.WriteLine($"   Оригинал: {original}");
            Console.WriteLine($"   Клон: {clone}");
            Console.WriteLine($"   Это один объект: {object.ReferenceEquals(original, clone)}");
        }

        /// <summary>
        /// Демонстрация кэширования.
        /// </summary>
        private static void DemonstrateCaching()
        {
            Console.WriteLine("\n4. КЭШИРОВАНИЕ:");

            Fraction f6 = new Fraction(1, 3);

            Console.WriteLine($"   Дробь: {f6}");
            Console.WriteLine($"   Вещественное значение: {f6.GetRealValue():F6}");
            Console.WriteLine($"   Еще раз: {f6.GetRealValue():F6}");

            f6.SetDenominator(5);

            Console.WriteLine($"\n   После изменения знаменателя: {f6}");
            Console.WriteLine($"   Новое значение: {f6.GetRealValue():F6}");
        }
    }
}