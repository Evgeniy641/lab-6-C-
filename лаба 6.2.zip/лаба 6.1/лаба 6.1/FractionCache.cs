﻿using System;

namespace FractionProject
{
    /// <summary>
    /// Интерфейс для работы с вещественным значением дроби.
    /// </summary>
    public interface IFractionOperations
    {
        /// <summary>
        /// Возвращает вещественное значение дроби.
        /// </summary>
        /// <returns>Вещественное значение.</returns>
        double GetRealValue();

        /// <summary>
        /// Устанавливает числитель.
        /// </summary>
        /// <param name="numerator">Новый числитель.</param>
        void SetNumerator(int numerator);

        /// <summary>
        /// Устанавливает знаменатель.
        /// </summary>
        /// <param name="denominator">Новый знаменатель.</param>
        /// <exception cref="ArgumentException">Выбрасывается при нулевом знаменателе.</exception>
        void SetDenominator(int denominator);
    }

    public partial class Fraction : IFractionOperations
    {
        private double? _cachedRealValue;
        private bool _isCacheValid = false;

        /// <summary>
        /// Возвращает вещественное значение с кэшированием.
        /// </summary>
        /// <returns>Вещественное значение дроби.</returns>
        public double GetRealValue()
        {
            if (!_isCacheValid || _cachedRealValue == null)
            {
                _cachedRealValue = (double)Numerator / Denominator;
                _isCacheValid = true;
            }

            return _cachedRealValue.Value;
        }

        /// <summary>
        /// Устанавливает новый числитель.
        /// </summary>
        /// <param name="numerator">Новый числитель.</param>
        public void SetNumerator(int numerator)
        {
            if (Numerator != numerator)
            {
                Numerator = numerator;
                Simplify();
                InvalidateCache();
            }
        }

        /// <summary>
        /// Устанавливает новый знаменатель.
        /// </summary>
        /// <param name="denominator">Новый знаменатель.</param>
        /// <exception cref="ArgumentException">Выбрасывается при нулевом знаменателе.</exception>
        public void SetDenominator(int denominator)
        {
            if (denominator == 0)
            {
                throw new ArgumentException("Знаменатель не может быть равен нулю");
            }

            if (Denominator != denominator)
            {
                Denominator = denominator;
                Simplify();
                InvalidateCache();
            }
        }

        /// <summary>
        /// Сбрасывает кэш.
        /// </summary>
        private void InvalidateCache()
        {
            _isCacheValid = false;
            _cachedRealValue = null;
        }
    }
}