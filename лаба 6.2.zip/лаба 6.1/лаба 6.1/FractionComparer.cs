﻿using System;

namespace FractionProject
{
    public partial class Fraction
    {
        /// <summary>
        /// Сравнивает две дроби.
        /// </summary>
        /// <param name="obj">Объект для сравнения.</param>
        /// <returns>True, если дроби равны.</returns>
        public override bool Equals(object obj)
        {
            if (obj is Fraction other)
            {
                var simplifiedThis = new Fraction(Numerator, Denominator);
                var simplifiedOther = new Fraction(other.Numerator, other.Denominator);

                return simplifiedThis.Numerator == simplifiedOther.Numerator &&
                       simplifiedThis.Denominator == simplifiedOther.Denominator;
            }

            return false;
        }

        /// <summary>
        /// Возвращает хэш-код.
        /// </summary>
        /// <returns>Хэш-код объекта.</returns>
        public override int GetHashCode()
        {
            var simplified = new Fraction(Numerator, Denominator);

            // Простое вычисление хэш-кода
            return simplified.Numerator.GetHashCode() ^ simplified.Denominator.GetHashCode();
        }

        /// <summary>
        /// Проверяет равенство дробей.
        /// </summary>
        /// <param name="left">Левая дробь.</param>
        /// <param name="right">Правая дробь.</param>
        /// <returns>True, если дроби равны.</returns>
        public static bool operator ==(Fraction left, Fraction right)
        {
            if (ReferenceEquals(left, right))
            {
                return true;
            }

            if (left is null || right is null)
            {
                return false;
            }

            return left.Equals(right);
        }

        /// <summary>
        /// Проверяет неравенство дробей.
        /// </summary>
        /// <param name="left">Левая дробь.</param>
        /// <param name="right">Правая дробь.</param>
        /// <returns>True, если дроби не равны.</returns>
        public static bool operator !=(Fraction left, Fraction right)
        {
            return !(left == right);
        }
    }
}