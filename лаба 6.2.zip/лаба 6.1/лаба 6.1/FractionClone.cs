﻿using System;

namespace FractionProject
{
    public partial class Fraction : ICloneable
    {
        /// <summary>
        /// Создает копию объекта.
        /// </summary>
        /// <returns>Копия дроби.</returns>
        public object Clone()
        {
            return new Fraction(Numerator, Denominator);
        }

        /// <summary>
        /// Создает глубокую копию.
        /// </summary>
        /// <returns>Глубокая копия дроби.</returns>
        public Fraction DeepCopy()
        {
            return (Fraction)Clone();
        }
    }
}