﻿using System;
using System.Collections.Generic;

namespace CatProject
{
    /// <summary>
    /// Класс для демонстрации подсчета мяуканий.
    /// </summary>
    public static class MeowCounterDemo
    {
        /// <summary>
        /// Демонстрирует работу с подсчетом мяуканий.
        /// </summary>
        public static void DemonstrateMeowCounting()
        {
            var countingCat = new Cat("Счетчик");
            var meowableList = new List<IMeowable>
            {
                countingCat,
                new RobotCat("RC-3000"),
                new Cat("Дополнительный")
            };

            MeowTester.MakeAllMeow(meowableList, 3);
        }

        /// <summary>
        /// Альтернативная демонстрация с использованием только интерфейса.
        /// </summary>
        /// <param name="cat">Кот для тестирования (через интерфейс).</param>
        public static void DemonstrateThroughInterface(IMeowable cat)
        {
            if (cat is Cat actualCat)
            {
                var testList = new List<IMeowable> { cat };
                MeowTester.MakeAllMeow(testList, 2);
            }
        }
    }
}