﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CatProject
{
    /// <summary>
    /// Основной класс программы для тестирования всех заданий.
    /// </summary>
    class Program
    {
        /// <summary>
        /// Точка входа в программу.
        /// </summary>
        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;

            Console.WriteLine("=== ЛАБОРАТОРНАЯ РАБОТА: КОТ ===");
            Console.WriteLine("===============================\n");

            ExecuteTask1();

            Console.WriteLine("\n" + new string('=', 50) + "\n");

            ExecuteTask2();

            Console.WriteLine("\n" + new string('=', 50) + "\n");

            ExecuteTask3();

            Console.WriteLine("\n" + new string('=', 50));
            Console.WriteLine("Все задания выполнены успешно!");
            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        /// <summary>
        /// Выполнение задания 1: Базовая функциональность кота.
        /// </summary>
        private static void ExecuteTask1()
        {
            Console.WriteLine("ЗАДАНИЕ 1: Кот мяукает");
            Console.WriteLine("-----------------------");

            try
            {
                var barsik = new Cat("Барсик");
                Console.WriteLine($"Создан: {barsik}");

                Console.WriteLine("\n1. Кот мяукает один раз:");
                barsik.Meow();

                Console.WriteLine("\n2. Кот мяукает три раза:");
                barsik.Meow(3);

                Console.WriteLine("\n3. Тестирование обработки ошибок:");

                try
                {
                    var invalidCat = new Cat("");
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"   Ошибка при создании кота: {ex.Message}");
                }

                try
                {
                    barsik.Meow(0);
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"   Ошибка при мяуканье: {ex.Message}");
                }

                try
                {
                    barsik.Meow(-5);
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"   Ошибка при мяуканье: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Неожиданная ошибка в задании 1: {ex.Message}");
            }
        }

        /// <summary>
        /// Выполнение задания 2: Интерфейс и метод для мяукающих объектов.
        /// </summary>
        private static void ExecuteTask2()
        {
            Console.WriteLine("ЗАДАНИЕ 2: Интерфейс Мяуканье");
            Console.WriteLine("-----------------------------");

            try
            {
                var cat1 = new Cat("Мурзик");
                var cat2 = new Cat("Васька");
                var cat3 = new Cat("Рыжик");
                var robotCat = new RobotCat("RC-2024");

                List<IMeowable> meowableObjects = new List<IMeowable>
                {
                    cat1,
                    cat2,
                    cat3,
                    robotCat
                };

                Console.WriteLine("Созданы следующие объекты:");
                int counter = 1;
                foreach (var obj in meowableObjects)
                {
                    Console.WriteLine($"  {counter}. {obj}");
                    counter++;
                }

                Console.WriteLine("\nТест 1: Одно мяуканье для всех объектов");
                MeowTester.MakeAllMeow(meowableObjects);

                Console.WriteLine("\nТест 2: Три мяуканья для всех объектов");
                MeowTester.MakeAllMeow(meowableObjects, 3);

                Console.WriteLine("\nТест 3: Работа с пустой коллекцией");
                var emptyList = new List<IMeowable>();
                MeowTester.MakeAllMeow(emptyList);

                Console.WriteLine("\nТест 4: Тестирование обработки ошибок");

                try
                {
                    MeowTester.MakeAllMeow(null);
                }
                catch (ArgumentNullException ex)
                {
                    Console.WriteLine($"   Ошибка при передаче null: {ex.Message}");
                }

                try
                {
                    MeowTester.MakeAllMeow(meowableObjects, 0);
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"   Ошибка при некорректном количестве повторений: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Неожиданная ошибка в задании 2: {ex.Message}");
            }
        }

        /// <summary>
        /// Выполнение задания 3: Количество мяуканий.
        /// </summary>
        private static void ExecuteTask3()
        {
            Console.WriteLine("ЗАДАНИЕ 3: Количество мяуканий");
            Console.WriteLine("------------------------------");

            try
            {
                // Тест 1: Основная демонстрация
                Console.WriteLine("\n=== Тест 1: Основная демонстрация ===");
                var countingCat = new Cat("Счетчик");
                Console.WriteLine($"Создан {countingCat}");

                var meowableList = new List<IMeowable>
                {
                    countingCat,
                    new RobotCat("RC-3000"),
                    new Cat("Дополнительный")
                };

                Console.WriteLine($"Перед вызовом метода: {countingCat.GetMeowCount()} мяуканий");
                MeowTester.MakeAllMeow(meowableList, 3);
                Console.WriteLine($"После вызова метода: {countingCat.GetMeowCount()} мяуканий");

                // Тест 2: Демонстрация через интерфейс
                Console.WriteLine("\n=== Тест 2: Демонстрация через интерфейс ===");
                var testCat = new Cat("Тестовый");
                Console.WriteLine($"Начальное количество мяуканий: {testCat.GetMeowCount()}");
                MeowCounterDemo.DemonstrateThroughInterface(testCat);
                Console.WriteLine($"Конечное количество мяуканий: {testCat.GetMeowCount()}");

                // Тест 3: Сброс счетчика
                Console.WriteLine("\n=== Тест 3: Сброс счетчика ===");
                var resetCat = new Cat("Сброс");
                Console.WriteLine($"До мяуканья: {resetCat.GetMeowCount()} мяуканий");
                resetCat.Meow();
                resetCat.Meow(2);
                Console.WriteLine($"После мяуканья: {resetCat.GetMeowCount()} мяуканий");
                resetCat.ResetMeowCount();
                Console.WriteLine($"После сброса: {resetCat.GetMeowCount()} мяуканий");

                // Тест 4: Смешанная коллекция
                Console.WriteLine("\n=== Тест 4: Смешанная коллекция ===");
                var mixedCat = new Cat("Смешанный");
                var mixedCollection = new List<IMeowable>
                {
                    new Cat("Первый"),
                    mixedCat,
                    new RobotCat("Робот-1"),
                    new Cat("Второй"),
                    new RobotCat("Робот-2")
                };

                int initialCount = mixedCat.GetMeowCount();
                Console.WriteLine($"Начальное количество мяуканий: {initialCount}");

                MeowTester.MakeAllMeow(mixedCollection, 2);

                int finalCount = mixedCat.GetMeowCount();
                Console.WriteLine($"Конечное количество мяуканий: {finalCount}");
                Console.WriteLine($"Разница: {finalCount - initialCount} мяуканий");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Неожиданная ошибка в задании 3: {ex.Message}");
            }
        }
    }
}