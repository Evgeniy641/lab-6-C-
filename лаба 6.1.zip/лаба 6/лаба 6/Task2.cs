﻿using System;
using System.Collections.Generic;

namespace CatProject
{
    /// <summary>
    /// Класс, представляющий роботизированного кота.
    /// </summary>
    public class RobotCat : IMeowable
    {
        /// <summary>
        /// Модель робокота.
        /// </summary>
        public string Model { get; }

        /// <summary>
        /// Создает нового робокота с указанной моделью.
        /// </summary>
        /// <param name="model">Модель робокота.</param>
        public RobotCat(string model)
        {
            Model = model;
        }

        /// <summary>
        /// Издает роботизированное мяуканье.
        /// </summary>
        public void Meow()
        {
            Console.WriteLine($"{Model} (робокот): бип-мяу!");
        }

        /// <summary>
        /// Возвращает строковое представление робокота.
        /// </summary>
        /// <returns>Строка в формате "робокот: Модель".</returns>
        public override string ToString()
        {
            return $"робокот: {Model}";
        }
    }

    /// <summary>
    /// Класс для тестирования объектов, способных мяукать.
    /// </summary>
    public static class MeowTester
    {
        /// <summary>
        /// Вызывает мяуканье у всех объектов в коллекции.
        /// </summary>
        /// <param name="meowableObjects">Коллекция мяукающих объектов.</param>
        /// <param name="repeatCount">Количество повторений (по умолчанию 1).</param>
        /// <exception cref="ArgumentNullException">Выбрасывается, если коллекция объектов равна null.</exception>
        /// <exception cref="ArgumentException">Выбрасывается, если количество повторений не положительное.</exception>
        public static void MakeAllMeow(IEnumerable<IMeowable> meowableObjects, int repeatCount = 1)
        {
            if (meowableObjects == null)
            {
                throw new ArgumentNullException(nameof(meowableObjects));
            }

            if (repeatCount <= 0)
            {
                throw new ArgumentException("Количество повторений должно быть положительным числом");
            }

            Console.WriteLine($"\nВсе объекты мяукают (повторений: {repeatCount}):");

            for (int repeat = 1; repeat <= repeatCount; repeat++)
            {
                if (repeatCount > 1)
                {
                    Console.WriteLine($"\n--- Повторение #{repeat} ---");
                }

                int count = 1;
                foreach (var obj in meowableObjects)
                {
                    Console.Write($"{count}. ");
                    obj.Meow();
                    count++;
                }
            }
        }
    }
}