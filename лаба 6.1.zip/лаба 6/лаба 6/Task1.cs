﻿using System;
using System.Text;

namespace CatProject
{
    /// <summary>
    /// Интерфейс для объектов, способных мяукать.
    /// </summary>
    public interface IMeowable
    {
        /// <summary>
        /// Издает мяукающий звук.
        /// </summary>
        void Meow();
    }

    /// <summary>
    /// Класс, представляющий кота.
    /// </summary>
    public class Cat : IMeowable
    {
        /// <summary>
        /// Имя кота.
        /// </summary>
        public string Name { get; }

        private int _meowCount;

        /// <summary>
        /// Создает нового кота с указанным именем.
        /// </summary>
        /// <param name="name">Имя кота.</param>
        /// <exception cref="ArgumentException">Выбрасывается, если имя пустое или состоит только из пробелов.</exception>
        public Cat(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException("Имя кота не может быть пустым");
            }

            Name = name;
            _meowCount = 0;
        }

        /// <summary>
        /// Издает одно мяуканье.
        /// </summary>
        public void Meow()
        {
            Console.WriteLine($"{Name}: мяу!");
            _meowCount++;
        }

        /// <summary>
        /// Издает мяуканье указанное количество раз.
        /// </summary>
        /// <param name="n">Количество мяуканий.</param>
        /// <exception cref="ArgumentException">Выбрасывается, если количество мяуканий не положительное.</exception>
        public void Meow(int n)
        {
            if (n <= 0)
            {
                throw new ArgumentException("Количество мяуканий должно быть положительным числом");
            }

            var result = new StringBuilder();

            for (int i = 0; i < n; i++)
            {
                result.Append("мяу");

                if (i < n - 1)
                {
                    result.Append("-");
                }
            }

            Console.WriteLine($"{Name}: {result}!");
            _meowCount += n;
        }

        /// <summary>
        /// Возвращает количество мяуканий, сделанных котом.
        /// </summary>
        /// <returns>Количество мяуканий.</returns>
        public int GetMeowCount()
        {
            return _meowCount;
        }

        /// <summary>
        /// Сбрасывает счетчик мяуканий.
        /// </summary>
        public void ResetMeowCount()
        {
            _meowCount = 0;
        }

        /// <summary>
        /// Возвращает строковое представление кота.
        /// </summary>
        /// <returns>Строка в формате "кот: Имя".</returns>
        public override string ToString()
        {
            return $"кот: {Name}";
        }
    }
}